package com.capgemini.imdbGroup4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.imdbGroup4.service.AdminService;

@RestController
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@RequestMapping(value="/admin-login", method=RequestMethod.POST)
	 public ModelAndView login(Model model,@ModelAttribute("id") String adminName, @ModelAttribute("password") String adminPassword)
	 {
		if(adminService.findByAdminNameAndAdminPassword(adminName,adminPassword)!=null) {
		
			ModelAndView mv=new ModelAndView();
			mv.setViewName("admin-home");
			return mv;

		}
		else {
			ModelAndView mv = new ModelAndView();
		
			mv.addObject("error", "Invalid Details");
			mv.setViewName("admin-login");
			return mv;
		}
		
	 }

}

/*
 package com.capgemini.imdbGroup4.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.imdbGroup4.service.LoginService;

@RestController
public class LoginController {
	@Autowired
	private LoginService loginService;
	@RequestMapping(value="/login", method = RequestMethod.POST)
	public ModelAndView login(Model model,@ModelAttribute("id") String id, @ModelAttribute("password") String password )
	{
		
		if(loginService.findByUserIdAndPassword(id, password) != null) {
			ModelAndView mv = new ModelAndView(); 
			mv.setViewName("home");
			return mv;
		}
		if(loginService.findByEmailIdAndPassword(id, password) != null) {
			ModelAndView mv = new ModelAndView(); 
			mv.setViewName("home");
			return mv;
		}
		else {
			ModelAndView mv = new ModelAndView();
			mv.addObject("error", "Invalid Details");
			mv.setViewName("login");
			return mv;
		}
    }

}

 */


